# Print Dashed Lines

This is a simple package that currently contains a single function, print_dashed_lines(), which can be used in all projects to create better segmented terminal output.  This is currently incorporated in many of my projects under a services.py file, but could be used directly in your main files.

Please visit [the github page](https://github.com/acecode116/print_dashed_lines) for more details and code review. :D
